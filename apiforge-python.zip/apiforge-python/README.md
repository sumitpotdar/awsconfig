# APIForge — Python + Separate Frontend

A Postman-like API testing tool with:
- **Backend**: Python FastAPI (proxy server — solves CORS)
- **Frontend**: Plain HTML/CSS/JS (host anywhere)

---

## 📁 Project Structure

```
apiforge-python/
├── backend/
│   ├── main.py            ← FastAPI proxy server
│   └── requirements.txt   ← Python dependencies
└── frontend/
    └── index.html         ← Standalone frontend (host anywhere)
```

---

## 🐍 Backend Setup (Python FastAPI)

### Requirements
- Python 3.8+

### 1. Go to the backend folder
```bash
cd backend
```

### 2. (Optional) Create a virtual environment
```bash
python -m venv venv
source venv/bin/activate        # Mac/Linux
venv\Scripts\activate           # Windows
```

### 3. Install dependencies
```bash
pip install -r requirements.txt
```

### 4. Run the server
```bash
python main.py
```

Backend runs at: **http://localhost:8000**

- API docs (Swagger): http://localhost:8000/docs
- Health check:       http://localhost:8000/health

---

## 🌐 Frontend Setup

The frontend is a **single HTML file** — no build step needed.

### Option A — Open directly in browser (quickest)
```
Just double-click frontend/index.html
```
Then set the Backend URL in the top bar to: `http://localhost:8000`

### Option B — Serve with Python (recommended)
```bash
cd frontend
python -m http.server 5500
```
Open: http://localhost:5500

### Option C — Host on any static server
Upload `frontend/index.html` to:
- **Netlify**: drag & drop the file
- **Vercel**: `vercel --prod`
- **GitHub Pages**: push to a repo
- **Nginx / Apache**: copy to web root

> ⚠️ If frontend is hosted on a different domain than backend,
> update `allow_origins` in `backend/main.py` to your frontend's URL.

---

## 🔧 Configuration

### Change backend port
Edit `backend/main.py`:
```python
uvicorn.run("main:app", host="0.0.0.0", port=8000)  # change port here
```

### Change allowed frontend origins (production)
Edit `backend/main.py`:
```python
app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://your-frontend.com"],  # replace * with your domain
    ...
)
```

### Change backend URL in frontend
The frontend has a **Backend URL** field in the top bar — just type the new URL there.

---

## ✨ Features
- HTTP methods: GET, POST, PUT, PATCH, DELETE, HEAD, OPTIONS
- Request Headers, Query Params, Body editors
- Auth: Bearer Token, API Key, Basic Auth
- JSON syntax-highlighted response viewer
- Response Headers viewer + time & size metrics
- Save requests into Collections (localStorage)
- Live backend connection indicator
