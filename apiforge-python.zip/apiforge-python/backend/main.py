"""
APIForge — Python FastAPI Backend
Proxy server that forwards API requests from the frontend,
bypassing browser CORS restrictions.
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, Dict, Any
import httpx
import time
import uvicorn

app = FastAPI(
    title="APIForge Backend",
    description="Proxy server for APIForge API Testing Tool",
    version="1.0.0"
)

# ─── CORS ─────────────────────────────────────────────────────────────────────
# Allow the frontend (any origin) to talk to this backend.
# In production, replace "*" with your actual frontend domain.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],          # e.g. ["https://your-frontend.com"]
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ─── MODELS ───────────────────────────────────────────────────────────────────
class ProxyRequest(BaseModel):
    url: str
    method: str = "GET"
    headers: Optional[Dict[str, str]] = {}
    body: Optional[str] = None
    timeout: Optional[int] = 30


class ProxyResponse(BaseModel):
    status: int
    status_text: str
    headers: Dict[str, str]
    body: str
    elapsed_ms: int
    size_bytes: int
    is_base64: bool = False


# ─── ROUTES ───────────────────────────────────────────────────────────────────
@app.get("/")
def root():
    return {
        "service": "APIForge Backend",
        "version": "1.0.0",
        "status": "running",
        "docs": "/docs"
    }


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/proxy", response_model=ProxyResponse)
async def proxy(req: ProxyRequest):
    """
    Forward any HTTP request to the target URL and return the response.
    This bypasses browser CORS restrictions since the request originates
    from the server, not the browser.
    """
    if not req.url:
        raise HTTPException(status_code=400, detail="URL is required")

    # Strip headers that would cause issues when forwarding
    BLOCKED_HEADERS = {"host", "content-length", "transfer-encoding", "connection"}
    safe_headers = {
        k: v for k, v in (req.headers or {}).items()
        if k.lower() not in BLOCKED_HEADERS
    }

    start = time.time()

    try:
        async with httpx.AsyncClient(
            timeout=req.timeout,
            follow_redirects=True,
            verify=False  # Set to True in strict prod environments
        ) as client:

            # Build request kwargs
            kwargs: Dict[str, Any] = {
                "method":  req.method.upper(),
                "url":     req.url,
                "headers": safe_headers,
            }

            # Attach body for non-GET/HEAD methods
            if req.body and req.method.upper() not in ("GET", "HEAD"):
                kwargs["content"] = req.body.encode("utf-8")

            response = await client.request(**kwargs)

        elapsed_ms = int((time.time() - start) * 1000)

        # Convert headers to plain dict
        resp_headers = dict(response.headers)

        # Decode body
        content_type = resp_headers.get("content-type", "")
        is_text = any(t in content_type for t in [
            "text", "json", "xml", "html", "javascript", "yaml"
        ])

        if is_text:
            body_str = response.text
            is_base64 = False
        else:
            import base64
            body_str = base64.b64encode(response.content).decode("utf-8")
            is_base64 = True

        return ProxyResponse(
            status=response.status_code,
            status_text=response.reason_phrase or "",
            headers=resp_headers,
            body=body_str,
            elapsed_ms=elapsed_ms,
            size_bytes=len(response.content),
            is_base64=is_base64,
        )

    except httpx.ConnectError:
        raise HTTPException(
            status_code=502,
            detail=f"Connection refused or DNS lookup failed for: {req.url}"
        )
    except httpx.TimeoutException:
        raise HTTPException(
            status_code=504,
            detail=f"Request timed out after {req.timeout} seconds"
        )
    except httpx.InvalidURL:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid URL: {req.url}"
        )
    except Exception as e:
        raise HTTPException(status_code=502, detail=str(e))


# ─── ENTRY POINT ──────────────────────────────────────────────────────────────
if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,       # Auto-reload on file changes (dev mode)
        log_level="info"
    )
