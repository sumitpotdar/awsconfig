# APIForge 🔧
Your own company API testing tool — like Postman, but self-hosted.

---

## ✅ Requirements
- [Node.js](https://nodejs.org/) v16 or higher

---

## 🚀 Setup & Run

### 1. Install dependencies
```bash
npm install
```

### 2. Start the server
```bash
node server.js
```

### 3. Open in browser
```
http://localhost:3000
```

That's it! No CORS errors — all requests are proxied through the local server.

---

## 📁 Project Structure
```
apiforge/
├── server.js          ← Express backend (proxy server)
├── package.json
└── public/
    └── index.html     ← Frontend UI
```

---

## ✨ Features
- Send HTTP requests: GET, POST, PUT, PATCH, DELETE, HEAD, OPTIONS
- Request Headers editor
- Request Body editor (JSON, Form Data, Raw)
- Query Params editor
- Auth support: Bearer Token, API Key, Basic Auth
- JSON syntax-highlighted response viewer
- Response Headers viewer
- Response time & size metrics
- Save requests into Collections (persisted in browser localStorage)

---

## 🔒 Notes
- The proxy server runs locally — your API keys never leave your machine.
- Collections are saved in your browser's `localStorage`.
- To run on a different port, change `PORT` in `server.js`.
