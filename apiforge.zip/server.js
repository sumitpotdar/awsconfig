const express = require('express');
const cors = require('cors');
const axios = require('axios');
const path = require('path');

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Serve the frontend HTML
app.use(express.static(path.join(__dirname, 'public')));

// ─── PROXY ENDPOINT ──────────────────────────────────────────────────────────
// All API requests go through here to bypass CORS
app.post('/proxy', async (req, res) => {
  const { url, method, headers, body } = req.body;

  if (!url) {
    return res.status(400).json({ error: 'URL is required' });
  }

  try {
    const startTime = Date.now();

    const axiosConfig = {
      url,
      method: method || 'GET',
      headers: headers || {},
      // Don't throw on non-2xx status codes — pass them back to the client
      validateStatus: () => true,
      // Return raw buffer so we can detect binary vs text
      responseType: 'arraybuffer',
      timeout: 30000,
    };

    if (body && !['GET', 'HEAD'].includes((method || 'GET').toUpperCase())) {
      axiosConfig.data = body;
    }

    const response = await axios(axiosConfig);
    const elapsed = Date.now() - startTime;

    // Convert response headers to plain object
    const responseHeaders = {};
    Object.entries(response.headers).forEach(([k, v]) => {
      responseHeaders[k] = v;
    });

    // Try to decode body as UTF-8 text
    let responseBody;
    const contentType = response.headers['content-type'] || '';
    const isText = /text|json|xml|html|javascript|yaml/.test(contentType);

    if (isText) {
      responseBody = Buffer.from(response.data).toString('utf-8');
    } else {
      responseBody = Buffer.from(response.data).toString('base64');
    }

    res.json({
      status: response.status,
      statusText: response.statusText,
      headers: responseHeaders,
      body: responseBody,
      isBase64: !isText,
      elapsed,
      size: response.data.length,
    });

  } catch (err) {
    // Network-level errors (DNS failure, timeout, connection refused, etc.)
    const message = err.code === 'ECONNREFUSED'  ? 'Connection refused — is the target server running?'
                  : err.code === 'ENOTFOUND'     ? `DNS lookup failed for "${url}" — check the URL`
                  : err.code === 'ETIMEDOUT'     ? 'Request timed out after 30 seconds'
                  : err.message;

    res.status(502).json({ error: message });
  }
});

app.listen(PORT, () => {
  console.log(`\n  ✅  APIForge server running at http://localhost:${PORT}`);
  console.log(`  📂  Open http://localhost:${PORT} in your browser\n`);
});
